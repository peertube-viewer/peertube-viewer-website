_peertube-viewer-rs() {
    local i cur prev opts cmds
    COMPREPLY=()
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"
    cmd=""
    opts=""

    for i in ${COMP_WORDS[@]}
    do
        case "${i}" in
            peertube-viewer-rs)
                cmd="peertube-viewer-rs"
                ;;
            
            *)
                ;;
        esac
    done

    case "${cmd}" in
        peertube-viewer-rs)
            opts=" -s -t -h -V -p -i -c  --use-raw-url --print-default-config --print-full-example-config --select-quality --local --use-torrent --trending --channels --let-nsfw --tag-nsfw --block-nsfw --no-color --color --help --version --chandle --player-args --player --torrent-downloader --torrent-downloader-args --instance --config  <initial-query>... "
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 1 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                
                --chandle)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --player-args)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --player)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                    -p)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --torrent-downloader)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --torrent-downloader-args)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --instance)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                    -i)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --config)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                    -c)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        
    esac
}

complete -F _peertube-viewer-rs -o bashdefault -o default peertube-viewer-rs
