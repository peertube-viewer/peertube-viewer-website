
using namespace System.Management.Automation
using namespace System.Management.Automation.Language

Register-ArgumentCompleter -Native -CommandName 'peertube-viewer-rs' -ScriptBlock {
    param($wordToComplete, $commandAst, $cursorPosition)

    $commandElements = $commandAst.CommandElements
    $command = @(
        'peertube-viewer-rs'
        for ($i = 1; $i -lt $commandElements.Count; $i++) {
            $element = $commandElements[$i]
            if ($element -isnot [StringConstantExpressionAst] -or
                $element.StringConstantType -ne [StringConstantType]::BareWord -or
                $element.Value.StartsWith('-') -or
                $element.Value -eq $wordToComplete) {
                break
        }
        $element.Value
    }) -join ';'

    $completions = @(switch ($command) {
        'peertube-viewer-rs' {
            [CompletionResult]::new('--chandle', 'chandle', [CompletionResultType]::ParameterName, 'Start browsing the videos of a channel with its handle (ex: name@instance.com)')
            [CompletionResult]::new('--player-args', 'player-args', [CompletionResultType]::ParameterName, 'Arguments to be passed to the player')
            [CompletionResult]::new('-p', 'p', [CompletionResultType]::ParameterName, 'Player to play the videos with')
            [CompletionResult]::new('--player', 'player', [CompletionResultType]::ParameterName, 'Player to play the videos with')
            [CompletionResult]::new('--torrent-downloader', 'torrent-downloader', [CompletionResultType]::ParameterName, 'Choose the torrent software to download the videos with')
            [CompletionResult]::new('--torrent-downloader-args', 'torrent-downloader-args', [CompletionResultType]::ParameterName, 'Arguments to be passed to the torrent downloader')
            [CompletionResult]::new('-i', 'i', [CompletionResultType]::ParameterName, 'Instance to be browsed')
            [CompletionResult]::new('--instance', 'instance', [CompletionResultType]::ParameterName, 'Instance to be browsed')
            [CompletionResult]::new('--search-engine', 'search-engine', [CompletionResultType]::ParameterName, 'Use a search engine (like sepiasearch)')
            [CompletionResult]::new('-c', 'c', [CompletionResultType]::ParameterName, 'Sets a custom config file')
            [CompletionResult]::new('--config', 'config', [CompletionResultType]::ParameterName, 'Sets a custom config file')
            [CompletionResult]::new('--use-raw-urls', 'use-raw-urls', [CompletionResultType]::ParameterName, 'The raw url to the video will be passed to the player instead of the url to web interface to watch it. It may be necessary for players without native support for peertube such as vlc. Some players (ex : mpv) may be able to show the video title in their interface if this option isn''t used')
            [CompletionResult]::new('--print-default-config', 'print-default-config', [CompletionResultType]::ParameterName, 'Print the default confing to stdout and exit')
            [CompletionResult]::new('--print-full-example-config', 'print-full-example-config', [CompletionResultType]::ParameterName, 'Print an example of all possible config options and exit')
            [CompletionResult]::new('-s', 's', [CompletionResultType]::ParameterName, 'When playing a video with this option, the user will be prompted to chose the video quality
 Note: this implies --use-raw-urls')
            [CompletionResult]::new('--select-quality', 'select-quality', [CompletionResultType]::ParameterName, 'When playing a video with this option, the user will be prompted to chose the video quality
 Note: this implies --use-raw-urls')
            [CompletionResult]::new('--local', 'local', [CompletionResultType]::ParameterName, 'Only browse video hosted on the instance you are connected to')
            [CompletionResult]::new('--use-torrent', 'use-torrent', [CompletionResultType]::ParameterName, 'Will download the video via the torrent downloader instead of playing it')
            [CompletionResult]::new('-t', 't', [CompletionResultType]::ParameterName, 'Will start browsing trending videos')
            [CompletionResult]::new('--trending', 'trending', [CompletionResultType]::ParameterName, 'Will start browsing trending videos')
            [CompletionResult]::new('--channels', 'channels', [CompletionResultType]::ParameterName, 'Will start searching video channels')
            [CompletionResult]::new('--let-nsfw', 'let-nsfw', [CompletionResultType]::ParameterName, 'Don''t tag nsfw results')
            [CompletionResult]::new('--tag-nsfw', 'tag-nsfw', [CompletionResultType]::ParameterName, 'Tag nsfw results. This is the default behavior. This flag is only useful to override the config file')
            [CompletionResult]::new('--block-nsfw', 'block-nsfw', [CompletionResultType]::ParameterName, 'Block nsfw search results')
            [CompletionResult]::new('--no-color', 'no-color', [CompletionResultType]::ParameterName, 'Remove coloring of output')
            [CompletionResult]::new('--color', 'color', [CompletionResultType]::ParameterName, 'Force coloring of output if it is disabled in the config file')
            [CompletionResult]::new('-V', 'V ', [CompletionResultType]::ParameterName, 'Print version')
            [CompletionResult]::new('--version', 'version', [CompletionResultType]::ParameterName, 'Print version')
            break
        }
    })

    $completions.Where{ $_.CompletionText -like "$wordToComplete*" } |
        Sort-Object -Property ListItemText
}
