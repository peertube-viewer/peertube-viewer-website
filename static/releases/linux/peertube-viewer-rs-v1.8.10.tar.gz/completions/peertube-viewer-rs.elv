
use builtin;
use str;

set edit:completion:arg-completer[peertube-viewer-rs] = {|@words|
    fn spaces {|n|
        builtin:repeat $n ' ' | str:join ''
    }
    fn cand {|text desc|
        edit:complex-candidate $text &display=$text' '(spaces (- 14 (wcswidth $text)))$desc
    }
    var command = 'peertube-viewer-rs'
    for word $words[1..-1] {
        if (str:has-prefix $word '-') {
            break
        }
        set command = $command';'$word
    }
    var completions = [
        &'peertube-viewer-rs'= {
            cand --chandle 'Start browsing the videos of a channel with its handle (ex: name@instance.com)'
            cand --player-args 'Arguments to be passed to the player'
            cand -p 'Player to play the videos with'
            cand --player 'Player to play the videos with'
            cand --torrent-downloader 'Choose the torrent software to download the videos with'
            cand --torrent-downloader-args 'Arguments to be passed to the torrent downloader'
            cand -i 'Instance to be browsed'
            cand --instance 'Instance to be browsed'
            cand --search-engine 'Use a search engine (like sepiasearch)'
            cand -c 'Sets a custom config file'
            cand --config 'Sets a custom config file'
            cand --use-raw-urls 'The raw url to the video will be passed to the player instead of the url to web interface to watch it. It may be necessary for players without native support for peertube such as vlc. Some players (ex : mpv) may be able to show the video title in their interface if this option isn''t used'
            cand --print-default-config 'Print the default confing to stdout and exit'
            cand --print-full-example-config 'Print an example of all possible config options and exit'
            cand -s 'When playing a video with this option, the user will be prompted to chose the video quality  Note: this implies --use-raw-urls'
            cand --select-quality 'When playing a video with this option, the user will be prompted to chose the video quality  Note: this implies --use-raw-urls'
            cand --local 'Only browse video hosted on the instance you are connected to'
            cand --use-torrent 'Will download the video via the torrent downloader instead of playing it'
            cand -t 'Will start browsing trending videos'
            cand --trending 'Will start browsing trending videos'
            cand --channels 'Will start searching video channels'
            cand --let-nsfw 'Don''t tag nsfw results'
            cand --tag-nsfw 'Tag nsfw results. This is the default behavior. This flag is only useful to override the config file'
            cand --block-nsfw 'Block nsfw search results'
            cand --no-color 'Remove coloring of output'
            cand --color 'Force coloring of output if it is disabled in the config file'
            cand -V 'Print version'
            cand --version 'Print version'
        }
    ]
    $completions[$command]
}
