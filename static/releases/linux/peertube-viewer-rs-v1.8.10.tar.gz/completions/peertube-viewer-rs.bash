_peertube-viewer-rs() {
    local i cur prev opts cmd
    COMPREPLY=()
    if [[ "${BASH_VERSINFO[0]}" -ge 4 ]]; then
        cur="$2"
    else
        cur="${COMP_WORDS[COMP_CWORD]}"
    fi
    prev="$3"
    cmd=""
    opts=""

    for i in "${COMP_WORDS[@]:0:COMP_CWORD}"
    do
        case "${cmd},${i}" in
            ",$1")
                cmd="peertube__viewer__rs"
                ;;
            *)
                ;;
        esac
    done

    case "${cmd}" in
        peertube__viewer__rs)
            opts="-s -t -p -i -c -V --use-raw-urls --print-default-config --print-full-example-config --select-quality --local --use-torrent --trending --channels --chandle --player-args --player --torrent-downloader --torrent-downloader-args --instance --search-engine --config --let-nsfw --tag-nsfw --block-nsfw --no-color --color --version [initial-query]..."
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 1 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --chandle)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --player-args)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --player)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -p)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --torrent-downloader)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --torrent-downloader-args)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --instance)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -i)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --search-engine)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --config)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                -c)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
    esac
}

if [[ "${BASH_VERSINFO[0]}" -eq 4 && "${BASH_VERSINFO[1]}" -ge 4 || "${BASH_VERSINFO[0]}" -gt 4 ]]; then
    complete -F _peertube-viewer-rs -o nosort -o bashdefault -o default peertube-viewer-rs
else
    complete -F _peertube-viewer-rs -o bashdefault -o default peertube-viewer-rs
fi
