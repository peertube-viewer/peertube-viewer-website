complete -c peertube-viewer-rs -l chandle -d 'Start browsing the videos of a channel with its handle (ex: name@instance.com)' -r
complete -c peertube-viewer-rs -l player-args -d 'Arguments to be passed to the player' -r
complete -c peertube-viewer-rs -s p -l player -d 'Player to play the videos with' -r
complete -c peertube-viewer-rs -l torrent-downloader -d 'Choose the torrent software to download the videos with' -r
complete -c peertube-viewer-rs -l torrent-downloader-args -d 'Arguments to be passed to the torrent downloader' -r
complete -c peertube-viewer-rs -s i -l instance -d 'Instance to be browsed' -r
complete -c peertube-viewer-rs -l search-engine -d 'Use a search engine (like sepiasearch)' -r
complete -c peertube-viewer-rs -s c -l config -d 'Sets a custom config file' -r
complete -c peertube-viewer-rs -l use-raw-urls -d 'The raw url to the video will be passed to the player instead of the url to web interface to watch it. It may be necessary for players without native support for peertube such as vlc. Some players (ex : mpv) may be able to show the video title in their interface if this option isn\'t used'
complete -c peertube-viewer-rs -l print-default-config -d 'Print the default confing to stdout and exit'
complete -c peertube-viewer-rs -l print-full-example-config -d 'Print an example of all possible config options and exit'
complete -c peertube-viewer-rs -s s -l select-quality -d 'When playing a video with this option, the user will be prompted to chose the video quality  Note: this implies --use-raw-urls'
complete -c peertube-viewer-rs -l local -d 'Only browse video hosted on the instance you are connected to'
complete -c peertube-viewer-rs -l use-torrent -d 'Will download the video via the torrent downloader instead of playing it'
complete -c peertube-viewer-rs -s t -l trending -d 'Will start browsing trending videos'
complete -c peertube-viewer-rs -l channels -d 'Will start searching video channels'
complete -c peertube-viewer-rs -l let-nsfw -d 'Don\'t tag nsfw results'
complete -c peertube-viewer-rs -l tag-nsfw -d 'Tag nsfw results. This is the default behavior. This flag is only useful to override the config file'
complete -c peertube-viewer-rs -l block-nsfw -d 'Block nsfw search results'
complete -c peertube-viewer-rs -l no-color -d 'Remove coloring of output'
complete -c peertube-viewer-rs -l color -d 'Force coloring of output if it is disabled in the config file'
complete -c peertube-viewer-rs -s V -l version -d 'Print version'
